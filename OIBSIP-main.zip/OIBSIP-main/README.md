# OASISINFOBYTE INTERNSHIP TASKS
<p>I have been selected as an intern at oasisinfobyte and some tasks have been assigned to me and i need to complete them in order to fullfill criteria for completion of this internship program.</p>
<p>The tasks are Machine Learning Tasks where i perform some analysis to find hidden insights in the given dataset, and perform EDA, Vizualisation, and then Model Building, Model Evalution, Model Testing.<p>
<h3>The Tasks that have given to me are : <h3>
 <h4><b>1.IRIS FLOWER CLASSIFICATION</b></h4>
   <p>Iris flower has three species; setosa, versicolor, and virginica, which differs according to their</br>
   measurements. Now assume that you have the measurements of the iris flowers according to
   their species, and here your task is to train a machine learning model that can learn from the
   measurements of the iris species and classify them.</p>
 <h4><b>2.UNEMPLOYMENT ANALYSIS WITH PYTHON</h4></b>
   <p>Unemployment is measured by the unemployment rate which is the number of people
   who are unemployed as a percentage of the total labour force. We have seen a sharp
   increase in the unemployment rate during Covid-19, so analyzing the unemployment rate
   can be a good data science project.</p> 
 <h4><b>3.CAR PRICE PREDICTION WITH MACHINE LEARNING</h4></b>
   <p>The price of a car depends on a lot of factors like the goodwill of the brand of the car,
   features of the car, horsepower and the mileage it gives and many more. Car price
   prediction is one of the major research areas in machine learning. So if you want to learn
   how to train a car price prediction model then this project is for you.</p>
 <h4><b>4.EMAIL SPAM DETECTION WITH MACHINE LEARNING</h4></b>
   <p>We’ve all been the recipient of spam emails before. Spam mail, or junk mail, is a type of email
   that is sent to a massive number of users at one time, frequently containing cryptic
   messages, scams, or most dangerously, phishing content.
   In this Project, use Python to build an email spam detector. Then, use machine learning to
   train the spam detector to recognize and classify emails into spam and non-spam. Let’s get started!</p>
 <h4><b>5.SALES PREDICTION USING PYTHON</h4></b>
   <p>Sales prediction means predicting how much of a product people will buy based on factors
   such as the amount you spend to advertise your product, the segment of people you
   advertise for, or the platform you are advertising on about your product.
   Typically, a product and service-based business always need their Data Scientist to predict
   their future sales with every step they take to manipulate the cost of advertising their
   product. So let’s start the task of sales prediction with machine learning using Python.</p>


